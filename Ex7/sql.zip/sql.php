<!DOCTYPE html>
<html>
<head>
	<title>php with DB</title>
</head>
<body>
	<form action="sql.php" method="post">
		<div>
			DB name :
			<input type="text" name="DB_name" />
			Query :
			<input type="box" name="query" />
		</div>
		<div>
			<input type="submit" name="submit" value="go!" />
		</div>
	</form>

	<div>
	<?php  
		try{
			$name = $_POST['DB_name'];
			$querys = $_POST['query'];
			$name = new PDO("mysql:dbname=".$name.";host=localhost", "root", "root");
			$name -> setAttribute(PDO::ATTR_ERRMOD, PDO::ERRMODE_EXCEPTION);
			$rows = $name -> query($querys);
			print_r($rows);

			foreach ($rows as $row) {
			?> <li><?= print_r($row); ?></li><?
			}

		} catch (PDOException $ex ) { ?>
			<p>error</p>
			<?
		}
		?>

</body>
</html>